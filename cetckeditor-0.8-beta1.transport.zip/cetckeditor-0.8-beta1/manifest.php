<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'Part of Content Editor Tools. Supports CET_assetsTV for file management.
Adds CKEditor as Rich Text Editor. You can add RTE to description and introtext. All settings in plugin\'s preferences tab.
Author Denis Dyranov (Dyranov.ru)
Thanks to donshakespeare and his TinymceWrapper for some code.
Version: 0.8',
    'changelog' => 'Changelog for Content Editor Tools CKEditor

0.8-beta1 (12.02.2016)
==========
- Added option for contetsCSS
- Added fuction to add custom plugins and options
- Added Sticky Toolbar option (best with "cet" Manager Theme)
- Added Outline Blocks on start option
- Parameter default_path changed to default_browser_path
- Config files now relative to CET_CKEditor folder
- Code review
- Bug fixes

0.7-beta1 (03.02.2016)
===========
- Added Bootstrap support
- Added CETTypograf plugin
— Added bootstrapTabs plugin
- UI improvments
- Bug fixes

0.5-beta1 (27.11.2015)
===========
- Initial Version',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '2d86f8b3c403f84bd297403bade6475b',
      'native_key' => 'cetckeditor',
      'filename' => 'modNamespace/afba98a9edc9fab832fc04386fbf875c.vehicle',
      'namespace' => 'cetckeditor',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '90ec98fe8ba1255259ce65a023d4bc27',
      'native_key' => 13,
      'filename' => 'modPlugin/d466bce3b8529563e4f8231c4f012fc7.vehicle',
      'namespace' => 'cetckeditor',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '64fe8da05e7237607762e33e46a3ba1e',
      'native_key' => 1,
      'filename' => 'modCategory/2a379e411d44bac11d5373b21494a607.vehicle',
      'namespace' => 'cetckeditor',
    ),
  ),
);