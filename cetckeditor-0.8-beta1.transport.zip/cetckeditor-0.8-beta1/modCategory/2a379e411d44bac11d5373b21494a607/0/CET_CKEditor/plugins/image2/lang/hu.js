﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'image2', 'hu', {
	alt: 'Buborék szöveg',
	btnUpload: 'Küldés a szerverre',
	captioned: 'Feliratozott kép',
	captionPlaceholder: 'Képfelirat',
	infoTab: 'Alaptulajdonságok',
	lockRatio: 'Arány megtartása',
	menu: 'Kép tulajdonságai',
	pathName: 'kép',
	pathNameCaption: 'felirat',
	resetSize: 'Eredeti méret',
	resizer: 'Kattints és húzz az átméretezéshez',
	title: 'Kép tulajdonságai',
	uploadTab: 'Feltöltés',
	urlMissing: 'Hiányzik a kép URL-je'
} );
